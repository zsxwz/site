case 'credits_paylog': include APP_PATH.'plugin/tt_credits/admin_creditslog.php'; break;
case 'credits_addbuy': include APP_PATH.'plugin/tt_credits/admin_addbuy.php'; break;
case 'credits_setuser': include APP_PATH.'plugin/tt_credits/admin_setuser.php'; break;
case 'credits_setcredits': include APP_PATH.'plugin/tt_credits/admin_setcredits.php'; break;
case 'credits_log': include APP_PATH.'plugin/tt_credits/admin_log.php'; break;
case 'credits_rank': include APP_PATH.'plugin/tt_credits/admin_rank.php'; break;