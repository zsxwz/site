<?php
/*
	插件升级文件
*/
!defined('DEBUG') AND exit('Forbidden');


?>